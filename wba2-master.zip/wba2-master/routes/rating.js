const express = require('express');
const router = express.Router();
const dt = require('../operations/newslogic')
const df = require('../operations/fundlogic')
const axios = require('axios');

const https = require('https');


router.get('/:company', function(req, res, next) {
    let company = req.params.company;
    let companyurl= encodeURI(company);
    let dataurl= 'https://newsapi.org/v2/everything?language=de&q='+companyurl+'&apiKey=b7c25bcc8daf49d7b8203d0bdd43c563';
    axios.get(dataurl)
        .then(response => {
            let dataobj= response.data.articles;
            console.log(dataobj);
            let a = dt.zoltar(dataobj); // function in newslogic.js
            console.log(a);
            res.send(a);
        })
        .catch(error => {
            console.log("------------- error". error);
        });
});
router.get('/ta/:symbol', function(req, res, next) {
    let symbol = req.params.symbol;
    let rsivalue= 'https://finnhub.io/api/v1/indicator?symbol='+symbol+'&resolution=D&from=1583098857&to=1584308457&indicator=rsi&timeperiod=3&token=br1frjvrh5reisn52uj0';
   // let rmavalue= 'https://finnhub.io/api/v1/indicator?symbol=SANT.DE&resolution=D&from=1583098857&to=1584308457&indicator=rma&timeperiod=3&token=br1frjvrh5reisn52uj0';
    //axios.all()
    axios.get(rsivalue)
        .then(response => {
            let rsivalue= response.data.rsi[9];
            console.log(rsivalue);
            let a = df.tan(rsivalue); // function in fundlogic.js
            res.send(a);
        })
        .catch(error => {
            console.log("------------- error". error);
        });
});
module.exports = router;