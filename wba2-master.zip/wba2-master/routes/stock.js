const express = require('express');
const router = express.Router();
const https = require('https');
const axios = require('axios');



/* /shares */
router.get('/', function(req, res, next) {
    console.log(req.query.search);
    let search = req.query.search
    let re = new RegExp(search, 'i');
    axios.get('https://finnhub.io/api/v1/stock/symbol?exchange=DE&token=br1frjvrh5reisn52uj0')
        .then(response => {
            let data = response.data;
            let datas = [];
            if(search) {
                for (var myindex in data) {
                    let ergebnis = data[myindex].description.match(re);
                    if (ergebnis) {
                        console.log(data[myindex]);
                        data[myindex]["company"] = "http://localhost:3000/shares/"+data[myindex].symbol+"";
                        datas.push(data[myindex]);
                    }
                }
            res.json(datas);
            }

            else{
            for(var myindex in data){
                data[myindex]["company"] = "http://localhost:3000/shares/"+data[myindex].symbol+"";
            }
            //console.log(data);
            res.json(data);}
        })
        .catch(error => {
            console.log("------------- error". error);
        });
});
router.get('/:share', function(req, res, next) {
    let symbol = req.params.share;
    let symbolurl= encodeURI(symbol);
    let url = 'https://finnhub.io/api/v1/stock/profile2?symbol='+symbolurl+'&token=br1frjvrh5reisn52uj0';
    axios.get(url)
        .then(response => {
            let data = response.data;
            let company = response.data.name;
            console.log(company);
            data["quote"] = 'http://localhost:3000/shares/'+symbolurl+'/quote';
            data["rating"] = 'http://localhost:3000/rating/'+company;
            data["t-rating"] = 'http://localhost:3000/rating/ta/'+symbolurl;
            res.send(response.data);
        })
        .catch(error => {
            console.log("------------- error". error);
        });
});
router.get('/:share/quote', function(req, res, next) {

    let symbol = req.params.share;
    let symbolurl= encodeURI(symbol);
    let url = 'https://finnhub.io/api/v1/quote?symbol='+symbolurl+'&token=br1frjvrh5reisn52uj0';
    axios.get(url)
        .then(response => {
            let data = response.data
            data["company"] = 'http://localhost:3000/shares/'+symbol;
            res.send(response.data);
        })
        .catch(error => {
            console.log("------------- error". error);
        });
});

module.exports = router;