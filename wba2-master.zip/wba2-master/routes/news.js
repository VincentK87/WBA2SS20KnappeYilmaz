const express = require('express');
const router = express.Router();
const axios = require('axios');



/* /news listen verzeichnis  */
router.get('/', function(req, res, next) {
// get top business headlines
    axios.get('https://newsapi.org/v2/top-headlines?country=de&category=business&apiKey=b7c25bcc8daf49d7b8203d0bdd43c563')
        .then(response => {
            console.log(response.data);
            res.send(response.data);
        })
        .catch(error => {
            console.log("------------- error". error);
        });

});
/* /news search  @param company  */
router.get('/:company', function(req, res, next) {
    let company = req.params.company;
    let url = 'https://newsapi.org/v2/top-headlines?country=de&category=business&q='+company+'&apiKey=b7c25bcc8daf49d7b8203d0bdd43c563';
    axios.get(url)
        .then(response => {
            console.log(response.data);
            res.send(response.data);
            console.log(company);
        })
        .catch(error => {
            console.log("------------- error". error);
        });
});

router.get('/company/:id', function(req, res, next) {
    let cid = (req.params.id);
    let cidp= encodeURI(cid);
    let url = 'https://newsapi.org/v2/everything?language=de&q='+cidp+'&apiKey=b7c25bcc8daf49d7b8203d0bdd43c563';
    axios.get(url)
        .then(response => {
            console.log(response.data);
            res.send(response.data);
        })
        .catch(error => {
            console.log("------------- error". error);
        });
});

module.exports = router;