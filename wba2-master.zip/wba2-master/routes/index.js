var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {

  let a = JSON.stringify(req.headers.accept);
  console.log(a);
  if (req.accepts('html')) {
    res.render('index', { title: 'AA-App' });
    return;
  }

  // respond with json
  if (req.accepts('json')) {
    res.send({ error: 'try root http://localhost:3000/shares' });
    return;
  }

});

module.exports = router;
