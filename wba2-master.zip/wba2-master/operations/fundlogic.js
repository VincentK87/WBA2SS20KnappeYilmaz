/**
 * Logic for Rating technical Analyses
 *
 */



// function
module.exports = {
    tan : function(rsi) {
        let json = {};
        let ges;
        json.rating = [];
        let ratingvalue = 0;
        Number(rsi);
        console.log(rsi)
        // RSI-Wert von über 70 überverkauft
        if (rsi>70) { ratingvalue -= 1;}
        //RSI-Wert unter 30 Kaufsignal
        else if(rsi < 30){ ratingvalue += 1; }

        ges = ratingvalue;
        if (ges>0){json.rating.push({tsignal:"green"});}
        else if(ges<0){json.rating.push({tsignal:"red"});}
        else if(ges===0){json.rating.push({tsignal:"yellow"});}

        return json;
    }
}